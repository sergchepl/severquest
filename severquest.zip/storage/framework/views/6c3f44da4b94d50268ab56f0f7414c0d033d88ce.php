<?php $__env->startSection('content'); ?>
    <!-- Если зашел как гость то видим правила и регистрацию -->
    <?php if(auth()->guard()->guest()): ?>
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group row">
            <label for="name" class="col-md-4 col-form-label text-md-right">Название команды</label>

            <div class="col-md-6">
                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" required autofocus>

                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="login" class="col-md-4 col-form-label text-md-right">Логин</label>

            <div class="col-md-6">
                <input id="login" type="login" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="login" required>
            </div>
        </div>

        <div class="form-group row">
            <label for="password" class="col-md-4 col-form-label text-md-right">Пароль</label>

            <div class="col-md-6">
                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Пароль(подтверждение)</label>

            <div class="col-md-6">
                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
            </div>
        </div>

        <div class="form-group row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-coral">
                    Погнали!
                </button>
                <a style="float:right" href="/login" role="button" class="btn btn-success">
                        Уже в Тимe!
                </a>
            </div>
        </div>
    </form>
    <?php else: ?>
    <div class="container-fluid">
        <div></div>
        <div class="row">
            <header class="col-12">
                <img src="/css/image/logo.jpg" alt="">
                <div onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"
                data-teamId='<?php echo e(Auth::user()->id); ?>' class="team"><?php echo e(Auth::user()->name); ?></div>
                
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                
            </header>
            <h1>Общие</h1>
            
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mt-2 <?php echo e((Auth::user()->id != $task->user_id) && $task->user_id ? ' disabled ' : ''); ?>" data-task="<?php echo e($task->id); ?>">
                        <div class="card-header" id="heading-<?php echo e($k); ?>">
                            <h5 class="mb-0">
                                <a data-toggle="collapse" href="#collapse-<?php echo e($k); ?>" aria-expanded="false">
                                    <?php echo e($task->name); ?>

                                </a>
                            </h5>
                        </div>
                    
                        <div id="collapse-<?php echo e($k); ?>" class="collapse" aria-labelledby="heading-<?php echo e($k); ?>">
                            <div class="card-body">
                                <?php echo $task->description; ?>

                                <button class="btn btn-coral btn-lg" role="button" <?php echo e((Auth::user()->id != $task->user_id) && $task->user_id ? ' disabled ' : ''); ?>>За дело!</button>
                                <button class="btn btn-danger hide btn-lg" role="button" >Отменись!</button>
                                <button style="float:right" class="btn btn-success btn-lg" role="button" <?php echo e(Auth::user()->id != $task->user_id ? ' disabled ' : ''); ?>>Хочу Сдать!</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>