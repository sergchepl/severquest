 
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(url('/store-photo')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <div class="custom-file">
                <input type="file" id="file" name="files[]" class="custom-file-input" multiple>
                <label class="custom-file-label" for="file" >Choose file</label>
            </div>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>